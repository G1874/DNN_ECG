#!/bin/bash

conda install python=3.10
conda install numpy=1.24.1
pip install -r requirements.txt