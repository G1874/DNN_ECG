#!/bin/bash

conda install python=3.11
conda install scikit-learn
pip install tensorflow