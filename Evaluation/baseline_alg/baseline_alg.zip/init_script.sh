#!/bin/bash

conda install python=3.11
conda install scikit-learn
pip install tensorflow
conda install wfdb	
pip install scipy==1.14.1